import rclpy
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from rclpy.action import ActionClient
from std_msgs.msg import String
import json


class SequentialWaypointNavigator(Node):

    def __init__(self):
        super().__init__('sequential_waypoint_navigator_node')

        # Replace YAML file handling with subscriber
        self.waypoints = []
        self.is_executing = False
        
        # Create subscriber for waypoints
        self.subscription = self.create_subscription(
            String,  # Using String msg type, assuming waypoints come as JSON string
            'waypoints_list',  # Topic name
            self.waypoints_callback,
            10
        )

        self.action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.get_logger().info("Waiting for NavigateToPose action server...")
        self.action_client.wait_for_server()
        self.current_waypoint_index = 0

        # Add publisher for navigation feedback
        self.feedback_publisher = self.create_publisher(
            String,  # Using String for simplicity, you could create a custom message type
            'navigation_feedback',  # Custom topic name
            10
        )

    def waypoints_callback(self, msg):
        try:
            new_waypoints = json.loads(msg.data)
            self.get_logger().info(f"Received new waypoints: {new_waypoints}")
            
            if self.is_executing:
                self.get_logger().warning("Received new waypoints while still executing previous ones!")
                return
                
            self.waypoints = new_waypoints
            self.current_waypoint_index = 0
            self.is_executing = True
            self.get_logger().info("Starting navigation...")
            self.navigate_to_next_waypoint()
            
        except json.JSONDecodeError as e:
            self.get_logger().error(f"Error parsing waypoints JSON: {e}")

    def navigate_to_next_waypoint(self):
        if self.current_waypoint_index >= len(self.waypoints):
            self.get_logger().info("All waypoints reached. Navigation complete.")
            self.is_executing = False
            # rclpy.shutdown()
            return

        waypoint = self.waypoints[self.current_waypoint_index]
        pose_msg = PoseStamped()
        pose_msg.header.frame_id = 'map'
        pose_msg.header.stamp = self.get_clock().now().to_msg()
        pose_msg.pose.position.x = float(waypoint['x'])
        pose_msg.pose.position.y = float(waypoint['y'])
        pose_msg.pose.position.z = float(waypoint['z'])
        pose_msg.pose.orientation.x = float(waypoint['qx'])
        pose_msg.pose.orientation.y = float(waypoint['qy'])
        pose_msg.pose.orientation.z = float(waypoint['qz'])
        pose_msg.pose.orientation.w = float(waypoint['qw'])

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose_msg

        self.get_logger().info(f"Navigating to waypoint {self.current_waypoint_index + 1}/{len(self.waypoints)}...")
        self.action_client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback).add_done_callback(
            self.goal_response_callback)

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        # self.get_logger().info(f"Feedback: Distance remaining: {feedback.distance_remaining:.2f} meters")

        # # Create feedback message
        # feedback_str = json.dumps({
        #     'distance_remaining': feedback.distance_remaining,
        #     'current_waypoint': self.current_waypoint_index + 1,
        #     'total_waypoints': len(self.waypoints)
        # })
        
        # Publish feedback
        # msg = String()
        # msg.data = feedback_str
        # self.feedback_publisher.publish(msg)
        
        # Optionally keep the logging as well
        #self.get_logger().info(f"Feedback: Distance remaining: {feedback.distance_remaining:.2f} meters")

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Goal was rejected by the NavigateToPose action server.")
            # rclpy.shutdown()
            return

        self.get_logger().info("Goal accepted by the NavigateToPose action server.")
        goal_handle.get_result_async().add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result()
        if result.status == 4:  # SUCCEEDED
            self.get_logger().info(f"Reached waypoint {self.current_waypoint_index + 1}/{len(self.waypoints)}")


            # Publish feedback
            feedback_str = json.dumps({
                'type': 'waypoint_reached',
                'current_waypoint': self.current_waypoint_index + 1,
                'total_waypoints': len(self.waypoints),
                'timestamp': self.get_clock().now().to_msg().sec
            })
            print(feedback_str)
            msg = String()
            msg.data = feedback_str
            self.feedback_publisher.publish(msg)

            self.current_waypoint_index += 1
            if self.current_waypoint_index >= len(self.waypoints):
                self.is_executing = False  # Reset execution flag when done
            self.navigate_to_next_waypoint()
        else:
            self.get_logger().error(f"Failed to reach waypoint {self.current_waypoint_index + 1}.")

            # Publish feedback
            feedback_str = json.dumps({
                'type': 'waypoint_failed',
                'current_waypoint': self.current_waypoint_index + 1,
                'total_waypoints': len(self.waypoints),
                'timestamp': self.get_clock().now().to_msg().sec
            })
            print(feedback_str)
            msg = String()
            msg.data = feedback_str
            self.feedback_publisher.publish(msg)

            self.is_executing = False  # Reset execution flag on failure
            self.waypoints = []
            self.current_waypoint_index = 0

            # rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = SequentialWaypointNavigator()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print('Caught keyboard interrupt')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
